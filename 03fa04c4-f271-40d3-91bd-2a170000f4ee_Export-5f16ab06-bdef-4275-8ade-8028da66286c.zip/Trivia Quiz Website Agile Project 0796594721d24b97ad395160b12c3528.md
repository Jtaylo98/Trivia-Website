# Trivia Quiz Website Agile Project

[Tickets](Trivia%20Quiz%20Website%20Agile%20Project%200796594721d24b97ad395160b12c3528/Tickets%20db088820fe7744558aed42ecb8c01924.md)

[Epics](Trivia%20Quiz%20Website%20Agile%20Project%200796594721d24b97ad395160b12c3528/Epics%20e351f1565b2c4549b3207d8dc73bbd89.csv)

[Sprints](Trivia%20Quiz%20Website%20Agile%20Project%200796594721d24b97ad395160b12c3528/Sprints%2024c5eea0891c42408474cbae47faf465.csv)

[Current Sprint](Trivia%20Quiz%20Website%20Agile%20Project%200796594721d24b97ad395160b12c3528/Current%20Sprint%204bfa6a1ed06a47af9af1a5a9946d7eff.md)

[Releases](Trivia%20Quiz%20Website%20Agile%20Project%200796594721d24b97ad395160b12c3528/Releases%2050d534704c36461da0ba04f29fede9c2.csv)

[Chores](Trivia%20Quiz%20Website%20Agile%20Project%200796594721d24b97ad395160b12c3528/Chores%200876839b87014775ae26bfdff39a44d2.csv)