# The quiz should span all questions in the question API

Priority: P3
Sprint Date: January 22, 2024 → February 2, 2024
Status: In Review
Chores: Ensure the app fetches all questions from the provided API (../../Chores%200876839b87014775ae26bfdff39a44d2/Ensure%20the%20app%20fetches%20all%20questions%20from%20the%20prov%208d9c31b6e58c43138904015030efa47d.md), Implement logic to iterate through all questions without reloading the page (../../Chores%200876839b87014775ae26bfdff39a44d2/Implement%20logic%20to%20iterate%20through%20all%20questions%20w%20994e2533d82d41798ff1701d8244de30.md)
Git Command: git checkout -b
Type: User Story
Complete?: Incomplete
Epics: Functionality (../../Epics%20e351f1565b2c4549b3207d8dc73bbd89/Functionality%20c53557b2617b496d937728a8fcd3e095.md)
Sprints: Sprint 3 (../../Sprints%2024c5eea0891c42408474cbae47faf465/Sprint%203%20f80b67df90184bb8be29262047b699ce.md)

AS A user

I WANT the quiz to include as many questions as possible 

SO THAT I can experience a comprehensive set of questions.

ACCEPTANCE CRITERIA

GIVEN the user starts a quiz session
WHEN they progress through questions
THEN they should eventually reach the end of the questions from the API without encountering a page reload.

GIVEN the user completes a quiz session
WHEN they restart the quiz
THEN they should start from the first question without reloading the page.