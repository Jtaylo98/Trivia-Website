# Place element that displays which question number the user is on and the total number of questions

Priority: P1
Sprint Date: December 29, 2023 → January 5, 2024
Status: Ready for Development
Chores: Design the Trivia Card Component (../../Chores%200876839b87014775ae26bfdff39a44d2/Design%20the%20Trivia%20Card%20Component%20a50757e23b2b4b4ea2b21ee0d5238553.md), Display the user's place as Question 1 / 10. (../../Chores%200876839b87014775ae26bfdff39a44d2/Display%20the%20user's%20place%20as%20Question%201%2010%20b341c2ac526d43718c8e34b7bda36d4a.md), Develop logic to prevent repeat questions unless progress is cleared (../../Chores%200876839b87014775ae26bfdff39a44d2/Develop%20logic%20to%20prevent%20repeat%20questions%20unless%20p%20521540e5a5b5472bb7537106cad268de.md), Implement a mechanism for tracking the user's progress. (../../Chores%200876839b87014775ae26bfdff39a44d2/Implement%20a%20mechanism%20for%20tracking%20the%20user's%20prog%2060dc8bd87e644a8da03bdd4bf33a15ba.md)
Git Command: git checkout -b
Type: User Story
Complete?: Incomplete
Epics: Quiz Interface (../../Epics%20e351f1565b2c4549b3207d8dc73bbd89/Quiz%20Interface%20424bba3a62374bfca7ab33aaf3f4cfc2.md)
Sprints: Sprint 1<< (../../Sprints%2024c5eea0891c42408474cbae47faf465/Sprint%201%2064ad3606d2e84bacb5277fad5a2f6372.md)

AS A user

I WANT an element displaying the current question number and the total number of questions

SO THAT I can track my progress within the quiz 

ACCEPTANCE CRITERIA

GIVEN the user is on the quiz page
WHEN they start a quiz session
THEN they should see a counter indicating the current question number and the total number of questions.

GIVEN the user is progressing through the quiz
WHEN they answer a question
THEN the counter should update to reflect the current question number.