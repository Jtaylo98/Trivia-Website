# Offer the user the ability to navigate to previous questions

Priority: P6
Sprint Date: March 12, 2024 → March 20, 2024
Status: Idea
Chores: Develop functionality for navigating back to previous questions. (../../Chores%200876839b87014775ae26bfdff39a44d2/Develop%20functionality%20for%20navigating%20back%20to%20previ%2077db76fbc78d4b9399d95d2f552be546.md), Ensure the user can review and potentially change previous answers (../../Chores%200876839b87014775ae26bfdff39a44d2/Ensure%20the%20user%20can%20review%20and%20potentially%20change%20%20baa1ae0211914016ba07ef66a5559ee0.md), Implement a mechanism for tracking the user's progress. (../../Chores%200876839b87014775ae26bfdff39a44d2/Implement%20a%20mechanism%20for%20tracking%20the%20user's%20prog%2060dc8bd87e644a8da03bdd4bf33a15ba.md)
Git Command: git checkout -b
Type: User Story
Complete?: Incomplete
Epics: Other/Extras (../../Epics%20e351f1565b2c4549b3207d8dc73bbd89/Other%20Extras%20b12dced4b62c4e9e9c3e97fcc475be8e.md), Considerations (../../Epics%20e351f1565b2c4549b3207d8dc73bbd89/Considerations%20ec4016d4f22947cd9d0e597323a56d97.md)
Sprints: Sprint 7 (../../Sprints%2024c5eea0891c42408474cbae47faf465/Sprint%207%20c04d105eb802485388ec07ba444fcc2e.md)

AS A user

I WANT the ability to navigate to previous questions 

SO THAT I can review and change my answers

ACCEPTANCE CRITERIA

- GIVEN a quiz session with multiple answered questions,
- WHEN I navigate to the previous question,
- THEN the software should allow me to review and potentially change my previous answers.