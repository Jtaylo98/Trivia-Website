# Display buttons for advancing to the next question once the current question has been answered

Priority: Done
Release: v1.0.2 (../../Releases%2050d534704c36461da0ba04f29fede9c2/v1%200%202%208331f1c3a3b74ac8a0e332fc35a2e1ef.md)
Status: Complete
Chores: Ensure buttons are visibly disabled when not applicable. (../../Chores%200876839b87014775ae26bfdff39a44d2/Ensure%20buttons%20are%20visibly%20disabled%20when%20not%20appli%2017c801f9c0014ef3a1df4ac74df08283.md), Display the user's place as Question 1 / 10. (../../Chores%200876839b87014775ae26bfdff39a44d2/Display%20the%20user's%20place%20as%20Question%201%2010%20b341c2ac526d43718c8e34b7bda36d4a.md)
Git Command: git checkout -b
Type: User Story
Complete?: Complete
Epics: Quiz Interface (../../Epics%20e351f1565b2c4549b3207d8dc73bbd89/Quiz%20Interface%20424bba3a62374bfca7ab33aaf3f4cfc2.md)

AS A user 

I WANT buttons to advance to the next question after answering the current question 

SO THAT I can proceed through the quiz in a structured manner.

ACCEPTANCE CRITERIA

GIVEN the user is participating in the quiz
WHEN they answer a question
THEN there should be a “Next” button and the "Next" button should become clickable.