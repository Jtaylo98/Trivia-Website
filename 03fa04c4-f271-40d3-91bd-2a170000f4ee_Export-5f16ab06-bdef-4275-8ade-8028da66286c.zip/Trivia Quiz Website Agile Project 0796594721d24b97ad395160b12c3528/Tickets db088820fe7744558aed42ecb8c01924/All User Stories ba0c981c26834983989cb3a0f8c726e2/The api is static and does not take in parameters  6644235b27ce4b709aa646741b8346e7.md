# The api is static and does not take in parameters or require a key, simply make your fetch to the above address

Priority: P3
Sprint Date: February 12, 2024 → February 16, 2024
Status: In Progress
Chores: Verify Static Nature (../../Chores%200876839b87014775ae26bfdff39a44d2/Verify%20Static%20Nature%2007f48f3515d94a2db1e3b17b17bf135d.md)
Git Command: git checkout -b
Type: User Story
Complete?: Incomplete
Epics: Functionality (../../Epics%20e351f1565b2c4549b3207d8dc73bbd89/Functionality%20c53557b2617b496d937728a8fcd3e095.md)
Sprints: Sprint 4  (../../Sprints%2024c5eea0891c42408474cbae47faf465/Sprint%204%2032435c49e0014b72b2d9b8c1593ce13b.md)

AS A developer,
I WANT the API to be static and not require parameters or a key,
SO THAT I can make a fetch request to the provided address without additional authentication.

Acceptance Criteria:

GIVEN a JavaScript function responsible for fetching questions from the API,
WHEN the function interacts with the API,
THEN the API should be static and not require any parameters or a key for access.
Requirements:

The API is expected to be static and devoid of parameters or key requirements.
Developers should be able to perform a fetch operation by requesting the specified address without additional parameters or authentication keys.