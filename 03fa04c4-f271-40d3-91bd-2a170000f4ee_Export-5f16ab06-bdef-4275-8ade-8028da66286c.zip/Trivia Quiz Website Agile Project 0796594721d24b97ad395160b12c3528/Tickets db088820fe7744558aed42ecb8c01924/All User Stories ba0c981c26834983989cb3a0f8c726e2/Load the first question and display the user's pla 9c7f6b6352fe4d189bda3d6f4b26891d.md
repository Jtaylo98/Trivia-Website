# Load the first question and display the user's place as Question 1 / 10

Priority: P3
Sprint Date: February 21, 2024 → February 28, 2024
Status: Ready for Development
Chores: Ensure the first question is loaded on page load (../../Chores%200876839b87014775ae26bfdff39a44d2/Ensure%20the%20first%20question%20is%20loaded%20on%20page%20load%207d7c3a1a729c48c088ffa71328402a39.md), Display the user's place as Question 1 / 10. (../../Chores%200876839b87014775ae26bfdff39a44d2/Display%20the%20user's%20place%20as%20Question%201%2010%20b341c2ac526d43718c8e34b7bda36d4a.md)
Git Command: git checkout -b
Type: User Story
Complete?: Incomplete
Epics: Functionality (../../Epics%20e351f1565b2c4549b3207d8dc73bbd89/Functionality%20c53557b2617b496d937728a8fcd3e095.md)
Sprints: Sprint 5 (../../Sprints%2024c5eea0891c42408474cbae47faf465/Sprint%205%20f16c1c2b402e402ba7440055f707b9d0.md)

*AS A user*

*I WANT the first question loaded on the page load with the user's place displayed as Question 1 / 10* 

*SO THAT I can start the quiz seamlessly.*

ACCEPTANCE CRITERIA

GIVEN the user loads the quiz,
WHEN the user starts the quiz,
THEN the first question should be loaded, and the user's place should be displayed as Question 1 / Total Questions.