# Make sure your User Experience design is intuitive

Priority: P4
Sprint Date: March 4, 2024 → March 8, 2024
Status: Requirements
Chores: Conduct a usability analysis of the current design. (../../Chores%200876839b87014775ae26bfdff39a44d2/Conduct%20a%20usability%20analysis%20of%20the%20current%20design%20fad6129771814a06b8877907d8349aaf.md), Implement clear and concise messages for user interactions. (../../Chores%200876839b87014775ae26bfdff39a44d2/Implement%20clear%20and%20concise%20messages%20for%20user%20inte%202e6fb8ee93bd462daba9d721c4c4f078.md), Ensure buttons are visibly disabled when not applicable. (../../Chores%200876839b87014775ae26bfdff39a44d2/Ensure%20buttons%20are%20visibly%20disabled%20when%20not%20appli%2017c801f9c0014ef3a1df4ac74df08283.md)
Git Command: git checkout -b
Type: User Story
Complete?: Incomplete
Epics: Considerations (../../Epics%20e351f1565b2c4549b3207d8dc73bbd89/Considerations%20ec4016d4f22947cd9d0e597323a56d97.md)
Sprints: Sprint 6 (../../Sprints%2024c5eea0891c42408474cbae47faf465/Sprint%206%2066b98543b55847cabad4d1ae4a4f80ff.md)

AS A user

I WANT an intuitive User Experience design 

SO THAT I can easily navigate and understand the functionality.

ACCEPTANCE CRITERIA

- GIVEN a quiz session,
- WHEN I interact with the app,
- THEN the buttons should be disabled when not applicable, and the messages should be clear and concise for easy understanding.