# Display a message to the user that informs them if their answer was right or wrong

Priority: P1
Sprint Date: January 8, 2024 → January 13, 2024
Status: In Review
Chores: Display a message indicating whether the user's answer was right or wrong (../../Chores%200876839b87014775ae26bfdff39a44d2/Display%20a%20message%20indicating%20whether%20the%20user's%20an%20d0c4b31b3948477789c928e93932db34.md), Style the message for clarity and visibility. (../../Chores%200876839b87014775ae26bfdff39a44d2/Style%20the%20message%20for%20clarity%20and%20visibility%20b5653bf90a024984bc519dfe694fc00e.md)
Git Command: git checkout -b
Type: User Story
Complete?: Incomplete
Epics: Quiz Interface (../../Epics%20e351f1565b2c4549b3207d8dc73bbd89/Quiz%20Interface%20424bba3a62374bfca7ab33aaf3f4cfc2.md)
Sprints: Sprint 2 (../../Sprints%2024c5eea0891c42408474cbae47faf465/Sprint%202%206493716a8ec5419d9465eb30026ee8e0.md)

AS A user

I WANT feedback messages for correct and incorrect answers

SO THAT I can understand how well I am performing in the quiz.

ACCEPTANCE CRITERIA

GIVEN the user has answered a question
WHEN the answer is submitted
THEN a message should be displayed indicating whether the answer was correct or incorrect.

GIVEN the user has completed the quiz
WHEN the final score is displayed
THEN a message should summarize their performance.