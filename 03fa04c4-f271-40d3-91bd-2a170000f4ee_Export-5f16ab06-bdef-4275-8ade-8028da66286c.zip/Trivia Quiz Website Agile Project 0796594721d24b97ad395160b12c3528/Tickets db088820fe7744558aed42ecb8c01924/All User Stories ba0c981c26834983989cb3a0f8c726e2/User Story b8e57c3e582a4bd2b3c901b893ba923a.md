# User Story

Git Command: git checkout -b
Type: User Story
Complete?: Incomplete

AS A…

I WANT…

SO THAT…

ACCEPTANCE CRITERIA

GIVEN [scenario)

WHEN [user does an action]

THEN [software should do what?]