# Play with formats for user interaction: drag 'n drop vs. click, etc.

Priority: P7
Sprint Date: March 12, 2024 → March 20, 2024
Status: Idea
Chores: Research and identify different interaction formats. (../../Chores%200876839b87014775ae26bfdff39a44d2/Research%20and%20identify%20different%20interaction%20format%20d8953b467f1b407ba19717ef4f99d896.md), Implement multiple interaction formats (e.g., drag 'n drop, click) as options (../../Chores%200876839b87014775ae26bfdff39a44d2/Implement%20multiple%20interaction%20formats%20(e%20g%20,%20drag%20778ef009c2a24e4891516cc87b7d10e3.md), Test the app with different interaction formats to gather user feedback. (../../Chores%200876839b87014775ae26bfdff39a44d2/Test%20the%20app%20with%20different%20interaction%20formats%20to%205fcb15de99564559926c476960946e20.md)
Git Command: git checkout -b
Type: User Story
Complete?: Incomplete
Epics: Other/Extras (../../Epics%20e351f1565b2c4549b3207d8dc73bbd89/Other%20Extras%20b12dced4b62c4e9e9c3e97fcc475be8e.md)
Sprints: Sprint 7 (../../Sprints%2024c5eea0891c42408474cbae47faf465/Sprint%207%20c04d105eb802485388ec07ba444fcc2e.md)

AS A user

I WANT to play with different formats for user interaction (e.g., drag 'n drop vs. click) 

SO THAT I can engage with the app in various ways

- ACCEPTANCE CRITERIA
    - GIVEN a quiz session,
    - WHEN I interact with the app,
    - THEN the software should offer different interaction formats, such as drag 'n drop or click, providing users with varied engagement options.