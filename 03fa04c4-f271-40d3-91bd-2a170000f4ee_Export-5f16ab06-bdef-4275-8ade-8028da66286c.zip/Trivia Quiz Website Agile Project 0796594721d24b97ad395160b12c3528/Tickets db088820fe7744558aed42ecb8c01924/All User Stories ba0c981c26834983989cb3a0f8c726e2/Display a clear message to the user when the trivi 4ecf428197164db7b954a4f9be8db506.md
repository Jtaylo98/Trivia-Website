# Display a clear message to the user when the trivia session is done, and include the user's score

Priority: P2
Sprint Date: January 8, 2024 → January 13, 2024
Status: In Review
Chores: Display a completion message. (../../Chores%200876839b87014775ae26bfdff39a44d2/Display%20a%20completion%20message%206bcfa7ec9fac4a15bb4b98f9c6a5e80d.md), Show the user's score in the completion message. (../../Chores%200876839b87014775ae26bfdff39a44d2/Show%20the%20user's%20score%20in%20the%20completion%20message%20059a41678dfe4edfbf339f0212263415.md)
Git Command: git checkout -b
Type: User Story
Complete?: Incomplete
Epics: Styling (../../Epics%20e351f1565b2c4549b3207d8dc73bbd89/Styling%2024121aa416ea432c867110868c74cd85.md)
Sprints: Sprint 2 (../../Sprints%2024c5eea0891c42408474cbae47faf465/Sprint%202%206493716a8ec5419d9465eb30026ee8e0.md)

AS A user

I WANT a clear message when the trivia session is done, including my score

SO THAT I can know my overall performance on the quiz.

ACCEPTANCE CRITERIA

GIVEN the user has completed the quiz
WHEN the final score is displayed
THEN a clear completion message should be shown along with the user's score.

GIVEN the user has completed the quiz
WHEN they view the completion message
THEN the message should encourage further engagement or action.