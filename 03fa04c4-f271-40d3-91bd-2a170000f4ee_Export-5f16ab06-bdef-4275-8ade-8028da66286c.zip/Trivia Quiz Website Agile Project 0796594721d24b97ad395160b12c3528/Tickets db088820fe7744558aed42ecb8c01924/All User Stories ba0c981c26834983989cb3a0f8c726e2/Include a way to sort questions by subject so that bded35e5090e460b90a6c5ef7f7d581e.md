# Include a way to sort questions by subject so that a user can answer questions specific to the subject of their choosing

Priority: P3
Sprint Date: February 12, 2024 → February 16, 2024
Status: In Progress
Chores: Investigate API response for subject information (../../Chores%200876839b87014775ae26bfdff39a44d2/Investigate%20API%20response%20for%20subject%20information%208748144453334967a14a5bbe0624a891.md), Implement sorting functionality based on subject. (../../Chores%200876839b87014775ae26bfdff39a44d2/Implement%20sorting%20functionality%20based%20on%20subject%20f56e79fd59ba486aa3ccc9102a0449b7.md)
Git Command: git checkout -b
Type: User Story
Complete?: Incomplete
Epics: Functionality (../../Epics%20e351f1565b2c4549b3207d8dc73bbd89/Functionality%20c53557b2617b496d937728a8fcd3e095.md)
Sprints: Sprint 4  (../../Sprints%2024c5eea0891c42408474cbae47faf465/Sprint%204%2032435c49e0014b72b2d9b8c1593ce13b.md)

*AS A user*

*I WANT the questions to be sorted by subject for a customized quiz experience* 

*SO THAT I can focus on specific topics.*

ACCEPTANCE CRITERIA

GIVEN the user is on the quiz page
WHEN they choose a specific subject
THEN the questions displayed should be filtered based on the selected subject.

GIVEN the user completes a quiz session on a specific subject
WHEN they start a new session
THEN the app should fetch questions from the chosen subject without reloading the page.