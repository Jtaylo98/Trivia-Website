# Track a user through sessions using some kind of backend persistence

Priority: P3
Sprint Date: February 12, 2024 → February 16, 2024
Status: Ready for Development
Chores: Implement backend persistence for user progress (../../Chores%200876839b87014775ae26bfdff39a44d2/Implement%20backend%20persistence%20for%20user%20progress%20a4c91c26266a42ab80a6a740f87e0d72.md), Develop logic to prevent repeat questions unless progress is cleared (../../Chores%200876839b87014775ae26bfdff39a44d2/Develop%20logic%20to%20prevent%20repeat%20questions%20unless%20p%20521540e5a5b5472bb7537106cad268de.md)
Git Command: git checkout -b
Type: User Story
Complete?: Incomplete
Epics: Functionality (../../Epics%20e351f1565b2c4549b3207d8dc73bbd89/Functionality%20c53557b2617b496d937728a8fcd3e095.md)
Sprints: Sprint 4  (../../Sprints%2024c5eea0891c42408474cbae47faf465/Sprint%204%2032435c49e0014b72b2d9b8c1593ce13b.md)

AS A user

I WANT my progress tracked across sessions with no repeated questions unless I clear my progress 

SO THAT I can have a personalized quiz journey

ACCEPTANCE CRITERIA

GIVEN the user is taking the quiz,
WHEN the user progresses through multiple sessions,
THEN the app should track and remember the user's progress, ensuring no repeated questions unless the progress is cleared.