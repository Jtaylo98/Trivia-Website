# Header item that includes the name of the app, and tabs

Priority: Done
Release: v1.0.2 (../../Releases%2050d534704c36461da0ba04f29fede9c2/v1%200%202%208331f1c3a3b74ac8a0e332fc35a2e1ef.md)
Status: Complete
Chores: Create a header component (../../Chores%200876839b87014775ae26bfdff39a44d2/Create%20a%20header%20component%20a05b04de029f43e29d3eeb22c79285f4.md)
Git Command: git checkout -b
Type: User Story
Complete?: Complete
Epics: Quiz Interface (../../Epics%20e351f1565b2c4549b3207d8dc73bbd89/Quiz%20Interface%20424bba3a62374bfca7ab33aaf3f4cfc2.md)

As a user 

I want a header with the app’s name and tabs for easy navigation 

So that I can start using the app right away without any confusion

ACCEPTANCE CRITERIA

GIVEN the user is on the app's main page
WHEN they look at the top of the page
THEN they should see a header with the app's name displayed prominently.

GIVEN the user is on the app's main page
WHEN they want to explore different sections and features
THEN they should be able to navigate using clearly labeled easy-to-understand tabs.