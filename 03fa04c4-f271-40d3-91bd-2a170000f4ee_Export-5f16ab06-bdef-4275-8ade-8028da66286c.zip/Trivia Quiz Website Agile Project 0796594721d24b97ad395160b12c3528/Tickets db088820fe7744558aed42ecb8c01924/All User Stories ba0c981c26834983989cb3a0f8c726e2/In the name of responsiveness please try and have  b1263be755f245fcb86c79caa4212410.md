# In the name of responsiveness: please try and have your answer buttons (or divs, or whatever you use) collapse into a column in small sizes (iPhone5, etc)

Priority: P5
Sprint Date: March 4, 2024 → March 8, 2024
Status: Triage
Chores: Identify the breakpoint for small-sized devices (e.g., iPhone5) (../../Chores%200876839b87014775ae26bfdff39a44d2/Identify%20the%20breakpoint%20for%20small-sized%20devices%20(e%2086d8b5e7bf124d4e9b094190901ba234.md), Implement a responsive design for answer buttons to switch to a column layout on small devices. (../../Chores%200876839b87014775ae26bfdff39a44d2/Implement%20a%20responsive%20design%20for%20answer%20buttons%20t%20b8eeee2001324dc99f032bce39ad5368.md), Test the responsiveness on small devices to ensure a smooth user experience. (../../Chores%200876839b87014775ae26bfdff39a44d2/Test%20the%20responsiveness%20on%20small%20devices%20to%20ensure%20265ce50165d64e4990219cd0e30df72a.md)
Git Command: git checkout -b
Type: User Story
Complete?: Incomplete
Epics: Other/Extras (../../Epics%20e351f1565b2c4549b3207d8dc73bbd89/Other%20Extras%20b12dced4b62c4e9e9c3e97fcc475be8e.md), Considerations (../../Epics%20e351f1565b2c4549b3207d8dc73bbd89/Considerations%20ec4016d4f22947cd9d0e597323a56d97.md)
Sprints: Sprint 6 (../../Sprints%2024c5eea0891c42408474cbae47faf465/Sprint%206%2066b98543b55847cabad4d1ae4a4f80ff.md)

AS A user 

I WANT answer buttons to collapse into a column in small sizes 

SO THAT I can comfortably use the app on small screens.

ACCEPTANCE CRITERIA

GIVEN the app on a small-sized device (e.g., iPhone5),
WHEN I view the answer buttons,
THEN the software should present the buttons in a column layout for improved usability.