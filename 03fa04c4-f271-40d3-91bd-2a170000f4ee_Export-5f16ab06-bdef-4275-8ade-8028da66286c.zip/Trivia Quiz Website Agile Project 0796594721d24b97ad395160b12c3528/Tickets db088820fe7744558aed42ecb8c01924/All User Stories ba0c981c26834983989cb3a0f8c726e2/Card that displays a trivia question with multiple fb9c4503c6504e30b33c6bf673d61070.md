# Card that displays a trivia question with multiple choice AND true/false questions

Priority: Done
Release: v1.0.2 (../../Releases%2050d534704c36461da0ba04f29fede9c2/v1%200%202%208331f1c3a3b74ac8a0e332fc35a2e1ef.md)
Status: Complete
Branch: Feature/Displays-trivia-questions
Chores: Create a header component (../../Chores%200876839b87014775ae26bfdff39a44d2/Create%20a%20header%20component%20a05b04de029f43e29d3eeb22c79285f4.md), Display the fetched question and answer options. (../../Chores%200876839b87014775ae26bfdff39a44d2/Display%20the%20fetched%20question%20and%20answer%20options%205dc6509e79aa44fca02e69bc8bacf811.md), Design the Trivia Card Component (../../Chores%200876839b87014775ae26bfdff39a44d2/Design%20the%20Trivia%20Card%20Component%20a50757e23b2b4b4ea2b21ee0d5238553.md), Handle True/False Questions (../../Chores%200876839b87014775ae26bfdff39a44d2/Handle%20True%20False%20Questions%20244a710beae2450c8e455f0fd5a0ba94.md), User Interaction with the Trivia Card (../../Chores%200876839b87014775ae26bfdff39a44d2/User%20Interaction%20with%20the%20Trivia%20Card%208c745ae01bce444a85a0204b1f64bfb2.md), Style Trivia Card for Readability (../../Chores%200876839b87014775ae26bfdff39a44d2/Style%20Trivia%20Card%20for%20Readability%2092588a19f2684402b035c77fb1093fbc.md), Integrate API Data with Card Component (../../Chores%200876839b87014775ae26bfdff39a44d2/Integrate%20API%20Data%20with%20Card%20Component%205af4f13e75fa4e359cc9d76934621f3c.md), Test Trivia Card Component (../../Chores%200876839b87014775ae26bfdff39a44d2/Test%20Trivia%20Card%20Component%20b6ef2645f8dc4b9cb17f99dacdb51876.md), Handle Loading and Error States (../../Chores%200876839b87014775ae26bfdff39a44d2/Handle%20Loading%20and%20Error%20States%2082c60605359a46638f162e5e704c78aa.md)
Git Command: git checkout -bFeature/Displays-trivia-questions
Type: User Story
Complete?: Complete
Epics: Quiz Interface (../../Epics%20e351f1565b2c4549b3207d8dc73bbd89/Quiz%20Interface%20424bba3a62374bfca7ab33aaf3f4cfc2.md)

AS A user

I WANT a card displaying trivia questions with multiple-choice and true/false options

SO THAT I can answer the questions and participate in the quiz.

ACCEPTANCE CRITERIA

GIVEN the user is on the quiz page
WHEN they start a quiz session
THEN they should see a card displaying a trivia question with multiple-choice and true/false options.

GIVEN the user is participating in the quiz
WHEN they answer a question
THEN the selected answer should be highlighted, and other options should be disabled.