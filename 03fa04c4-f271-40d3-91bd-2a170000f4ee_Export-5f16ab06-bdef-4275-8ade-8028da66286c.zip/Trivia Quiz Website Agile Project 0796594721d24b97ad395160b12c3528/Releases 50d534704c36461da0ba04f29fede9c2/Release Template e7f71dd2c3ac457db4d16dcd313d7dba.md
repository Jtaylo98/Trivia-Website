# Release Template

# **Release Notes**

In this release of the Trivia Quiz App, we have…

## Tickets for Release

[Untitled Database](Release%20Template%20e7f71dd2c3ac457db4d16dcd313d7dba/Untitled%20Database%2078f0cb8497fe49c8ba1890b443ede3af.csv)