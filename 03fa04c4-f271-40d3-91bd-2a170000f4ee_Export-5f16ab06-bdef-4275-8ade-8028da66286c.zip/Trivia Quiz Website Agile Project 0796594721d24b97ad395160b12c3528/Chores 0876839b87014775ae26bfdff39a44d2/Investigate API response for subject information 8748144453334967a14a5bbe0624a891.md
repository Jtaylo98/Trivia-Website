# Investigate API response for subject information

All User Stories: Include a way to sort questions by subject so that a user can answer questions specific to the subject of their choosing (../Tickets%20db088820fe7744558aed42ecb8c01924/All%20User%20Stories%20ba0c981c26834983989cb3a0f8c726e2/Include%20a%20way%20to%20sort%20questions%20by%20subject%20so%20that%20bded35e5090e460b90a6c5ef7f7d581e.md)
Epics 1: Functionality (../Epics%20e351f1565b2c4549b3207d8dc73bbd89/Functionality%20c53557b2617b496d937728a8fcd3e095.md)
Sprint Dates: February 12, 2024 → February 16, 2024
Sprints: Sprint 4  (../Sprints%2024c5eea0891c42408474cbae47faf465/Sprint%204%2032435c49e0014b72b2d9b8c1593ce13b.md)

Create a task item to satisfy the acceptance criteria and fulfill the user story.