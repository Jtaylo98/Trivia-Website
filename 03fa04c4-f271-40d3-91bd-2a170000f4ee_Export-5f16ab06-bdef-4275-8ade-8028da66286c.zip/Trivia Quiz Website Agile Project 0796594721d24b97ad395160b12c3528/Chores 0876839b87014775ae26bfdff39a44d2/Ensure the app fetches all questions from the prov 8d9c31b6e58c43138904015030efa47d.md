# Ensure the app fetches all questions from the provided API

All User Stories: The quiz should span all questions in the question API (../Tickets%20db088820fe7744558aed42ecb8c01924/All%20User%20Stories%20ba0c981c26834983989cb3a0f8c726e2/The%20quiz%20should%20span%20all%20questions%20in%20the%20question%20673e7a98f6bc47f2990bb4783f7d245c.md)
Epics 1: Functionality (../Epics%20e351f1565b2c4549b3207d8dc73bbd89/Functionality%20c53557b2617b496d937728a8fcd3e095.md)
Sprint Dates: January 22, 2024 → February 2, 2024
Sprints: Sprint 3 (../Sprints%2024c5eea0891c42408474cbae47faf465/Sprint%203%20f80b67df90184bb8be29262047b699ce.md)

Create a task item to satisfy the acceptance criteria and fulfill the user story.

**Fetch Question from API:**

- Create a function to fetch all questions from the trivia API (**`https://johnmeade-webdev.github.io/chingu_quiz_api/trial.json`**).
- Handle the API response, ensuring it is successful.
- Extract the questions and answer options from the API response.

**Acceptance Criteria:**

- When the function is called, it should successfully fetch a question with options from the API.
- When the function is called, it should pull all questions from the provided API