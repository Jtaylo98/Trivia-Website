# Style the message for clarity and visibility.

All User Stories: Display a message to the user that informs them if their answer was right or wrong (../Tickets%20db088820fe7744558aed42ecb8c01924/All%20User%20Stories%20ba0c981c26834983989cb3a0f8c726e2/Display%20a%20message%20to%20the%20user%20that%20informs%20them%20if%20d5bac4056670491e92273c1a617211c2.md)
Epics 1: Quiz Interface (../Epics%20e351f1565b2c4549b3207d8dc73bbd89/Quiz%20Interface%20424bba3a62374bfca7ab33aaf3f4cfc2.md)
Sprint Dates: January 8, 2024 → January 13, 2024
Sprints: Sprint 2 (../Sprints%2024c5eea0891c42408474cbae47faf465/Sprint%202%206493716a8ec5419d9465eb30026ee8e0.md)

Create a task item to satisfy the acceptance criteria and fulfill the user story.

**Style the message for clarity and visibility.**

- Make messages indicating that the answer was correct green and make messages indicating that messages are incorrect red

**Acceptance Criteria**

- When a user gets a correct answer, the message displayed will be styled in green and when the user gets an incorrect answer the message will be styled in red