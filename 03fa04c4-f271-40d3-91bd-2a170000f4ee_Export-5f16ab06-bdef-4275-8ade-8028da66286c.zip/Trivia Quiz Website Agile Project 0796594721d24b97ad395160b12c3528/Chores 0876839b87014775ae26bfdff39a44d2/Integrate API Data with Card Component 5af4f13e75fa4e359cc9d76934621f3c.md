# Integrate API Data with Card Component

All User Stories: Card that displays a trivia question with multiple choice AND true/false questions (../Tickets%20db088820fe7744558aed42ecb8c01924/All%20User%20Stories%20ba0c981c26834983989cb3a0f8c726e2/Card%20that%20displays%20a%20trivia%20question%20with%20multiple%20fb9c4503c6504e30b33c6bf673d61070.md)
Epics 1: Functionality (../Epics%20e351f1565b2c4549b3207d8dc73bbd89/Functionality%20c53557b2617b496d937728a8fcd3e095.md)
Priority: P3
Team: DevOps

Create a task item to satisfy the acceptance criteria and fulfill the user story.

**Integrate API Data with Card Component**:

Use the data fetched from the API to dynamically populate the question and answer options within the trivia card.
Update the content of the card based on the fetched question.
**Acceptance Criteria**:

When a question is fetched, the trivia card should display the question and answer options.