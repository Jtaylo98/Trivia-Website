# Display the fetched question and answer options.

All User Stories: Card that displays a trivia question with multiple choice AND true/false questions (../Tickets%20db088820fe7744558aed42ecb8c01924/All%20User%20Stories%20ba0c981c26834983989cb3a0f8c726e2/Card%20that%20displays%20a%20trivia%20question%20with%20multiple%20fb9c4503c6504e30b33c6bf673d61070.md)
Assignee: Joe Taylor
Epics 1: Quiz Interface (../Epics%20e351f1565b2c4549b3207d8dc73bbd89/Quiz%20Interface%20424bba3a62374bfca7ab33aaf3f4cfc2.md)
Priority: P2
Team: Design

Create a function to fetch a question from the trivia API ([https://johnmeade-webdev.github.io/chingu_quiz_api/trial.json](https://johnmeade-webdev.github.io/chingu_quiz_api/trial.json)).