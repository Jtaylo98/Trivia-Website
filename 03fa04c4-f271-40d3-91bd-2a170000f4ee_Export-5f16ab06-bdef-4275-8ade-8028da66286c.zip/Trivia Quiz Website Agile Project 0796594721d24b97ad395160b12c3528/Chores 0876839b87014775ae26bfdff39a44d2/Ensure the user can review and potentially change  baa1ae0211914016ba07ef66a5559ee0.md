# Ensure the user can review and potentially change previous answers

All User Stories: Offer the user the ability to navigate to previous questions (../Tickets%20db088820fe7744558aed42ecb8c01924/All%20User%20Stories%20ba0c981c26834983989cb3a0f8c726e2/Offer%20the%20user%20the%20ability%20to%20navigate%20to%20previous%2050c91a4c69954603a4bfe01382e92c4c.md)
Epics 1: Other/Extras (../Epics%20e351f1565b2c4549b3207d8dc73bbd89/Other%20Extras%20b12dced4b62c4e9e9c3e97fcc475be8e.md)
Sprint Dates: March 12, 2024 → March 20, 2024
Sprints: Sprint 7 (../Sprints%2024c5eea0891c42408474cbae47faf465/Sprint%207%20c04d105eb802485388ec07ba444fcc2e.md)