# Ensure buttons are visibly disabled when not applicable.

All User Stories: Make sure your User Experience design is intuitive (../Tickets%20db088820fe7744558aed42ecb8c01924/All%20User%20Stories%20ba0c981c26834983989cb3a0f8c726e2/Make%20sure%20your%20User%20Experience%20design%20is%20intuitive%20fa683c3ae66e49e0a1ba40b25b151db3.md), Display buttons for advancing to the next question once the current question has been answered (../Tickets%20db088820fe7744558aed42ecb8c01924/All%20User%20Stories%20ba0c981c26834983989cb3a0f8c726e2/Display%20buttons%20for%20advancing%20to%20the%20next%20question%2090b4b198a57546fc85b484d620f5cd88.md)
Epics 1: Considerations (../Epics%20e351f1565b2c4549b3207d8dc73bbd89/Considerations%20ec4016d4f22947cd9d0e597323a56d97.md)
Sprint Dates: March 4, 2024 → March 8, 2024
Sprints: Sprint 6 (../Sprints%2024c5eea0891c42408474cbae47faf465/Sprint%206%2066b98543b55847cabad4d1ae4a4f80ff.md)

Create a task item to satisfy the acceptance criteria and fulfill the user story.