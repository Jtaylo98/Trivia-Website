# Develop logic to prevent repeat questions unless progress is cleared

All User Stories: Track a user through sessions using some kind of backend persistence (../Tickets%20db088820fe7744558aed42ecb8c01924/All%20User%20Stories%20ba0c981c26834983989cb3a0f8c726e2/Track%20a%20user%20through%20sessions%20using%20some%20kind%20of%20b%207d0e1488aba44c049812bafe2ef1d984.md), Place element that displays which question number the user is on and the total number of questions (../Tickets%20db088820fe7744558aed42ecb8c01924/All%20User%20Stories%20ba0c981c26834983989cb3a0f8c726e2/Place%20element%20that%20displays%20which%20question%20number%20%2002e2c3a470bd496999246e74c04c1907.md)
Epics 1: Functionality (../Epics%20e351f1565b2c4549b3207d8dc73bbd89/Functionality%20c53557b2617b496d937728a8fcd3e095.md)
Sprint Dates: December 29, 2023 → January 5, 2024,February 12, 2024 → February 16, 2024
Sprints: Sprint 1<< (../Sprints%2024c5eea0891c42408474cbae47faf465/Sprint%201%2064ad3606d2e84bacb5277fad5a2f6372.md), Sprint 4  (../Sprints%2024c5eea0891c42408474cbae47faf465/Sprint%204%2032435c49e0014b72b2d9b8c1593ce13b.md)

Create a task item to satisfy the acceptance criteria and fulfill the user story.