# Ensure the first question is loaded on page load

All User Stories: Load the first question and display the user's place as Question 1 / 10 (../Tickets%20db088820fe7744558aed42ecb8c01924/All%20User%20Stories%20ba0c981c26834983989cb3a0f8c726e2/Load%20the%20first%20question%20and%20display%20the%20user's%20pla%209c7f6b6352fe4d189bda3d6f4b26891d.md)
Epics 1: Functionality (../Epics%20e351f1565b2c4549b3207d8dc73bbd89/Functionality%20c53557b2617b496d937728a8fcd3e095.md)
Sprint Dates: February 21, 2024 → February 28, 2024
Sprints: Sprint 5 (../Sprints%2024c5eea0891c42408474cbae47faf465/Sprint%205%20f16c1c2b402e402ba7440055f707b9d0.md)