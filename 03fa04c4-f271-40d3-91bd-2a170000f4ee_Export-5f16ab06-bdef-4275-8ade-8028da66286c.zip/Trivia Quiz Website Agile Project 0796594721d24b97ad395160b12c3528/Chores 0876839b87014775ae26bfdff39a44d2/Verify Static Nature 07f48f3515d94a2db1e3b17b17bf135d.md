# Verify Static Nature

All User Stories: The api is static and does not take in parameters or require a key, simply make your fetch to the above address (../Tickets%20db088820fe7744558aed42ecb8c01924/All%20User%20Stories%20ba0c981c26834983989cb3a0f8c726e2/The%20api%20is%20static%20and%20does%20not%20take%20in%20parameters%20%206644235b27ce4b709aa646741b8346e7.md)
Epics 1: Functionality (../Epics%20e351f1565b2c4549b3207d8dc73bbd89/Functionality%20c53557b2617b496d937728a8fcd3e095.md)
Sprint Dates: February 12, 2024 → February 16, 2024
Sprints: Sprint 4  (../Sprints%2024c5eea0891c42408474cbae47faf465/Sprint%204%2032435c49e0014b72b2d9b8c1593ce13b.md)

Create a task item to satisfy the acceptance criteria and fulfill the user story.

Verify Static Nature:

- Acceptance Criteria:
    - Given the fetch function is executed,
    - When it interacts with the API,
    - Then the API does not require any parameters for a successful interaction.