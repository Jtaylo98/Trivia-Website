# Handle True/False Questions

All User Stories: Card that displays a trivia question with multiple choice AND true/false questions (../Tickets%20db088820fe7744558aed42ecb8c01924/All%20User%20Stories%20ba0c981c26834983989cb3a0f8c726e2/Card%20that%20displays%20a%20trivia%20question%20with%20multiple%20fb9c4503c6504e30b33c6bf673d61070.md)
Epics 1: Functionality (../Epics%20e351f1565b2c4549b3207d8dc73bbd89/Functionality%20c53557b2617b496d937728a8fcd3e095.md)
Priority: P3
Team: DevOps

Create a task item to satisfy the acceptance criteria and fulfill the user story.

**Handle True/False Questions**:

Modify the trivia card component to handle true/false questions appropriately.
Ensure the layout and styling adjust for true/false options.
**Acceptance Criteria**:

True/false questions should be displayed in a user-friendly manner within the trivia card.