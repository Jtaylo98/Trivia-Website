# Create a header component

All User Stories: Card that displays a trivia question with multiple choice AND true/false questions (../Tickets%20db088820fe7744558aed42ecb8c01924/All%20User%20Stories%20ba0c981c26834983989cb3a0f8c726e2/Card%20that%20displays%20a%20trivia%20question%20with%20multiple%20fb9c4503c6504e30b33c6bf673d61070.md), Header item that includes the name of the app, and tabs (../Tickets%20db088820fe7744558aed42ecb8c01924/All%20User%20Stories%20ba0c981c26834983989cb3a0f8c726e2/Header%20item%20that%20includes%20the%20name%20of%20the%20app,%20and%20c8d31d27349f4dffbe0658e69ed69163.md)
Assignee: Joe Taylor
Epics 1: Quiz Interface (../Epics%20e351f1565b2c4549b3207d8dc73bbd89/Quiz%20Interface%20424bba3a62374bfca7ab33aaf3f4cfc2.md)
Priority: P1
Team: Design

Create a task item to satisfy the acceptance criteria and fulfill the user story.